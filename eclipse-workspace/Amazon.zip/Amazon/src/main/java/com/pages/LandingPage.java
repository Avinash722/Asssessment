package com.pages;

import org.openqa.selenium.WebDriver;

public class LandingPage {
	WebDriver driver;

}
