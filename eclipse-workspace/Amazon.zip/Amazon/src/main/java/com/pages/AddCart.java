package com.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.qa.TestBase.BaseClass;

public class AddCart extends BaseClass {
	
	/*@FindBy(xpath = ("//*[@id=\"nav-xshop\"]/a[5]"))
	WebElement book;
	@FindBy(xpath = ("//span[text()='Rooh । रूह'] "))
	WebElement deatils ;
	@FindBy(xpath = (("//input[@id='add-to-cart-button']")))
	WebElement add;
	@FindBy(xpath = (("//span[contains(text(),'Added to Cart')]")))
	WebElement msg;*/


	public  void test() throws InterruptedException  {
		System.out.println("dfdsjfdfs");
		
		driver.findElement(By.xpath("//*[@id=\"nav-xshop\"]/a[5]")).click();
		System.out.println("ffffff");
		//book.click();
		
		Thread.sleep(1000);
		//deatils.click();
		Thread.sleep(1000);
		//add.click();
		Thread.sleep(1000);
		
		
	}
/*public String getSuccessMessage() {
		
		String added=msg.getText();
		
		System.out.println("Success site edited  " +added);
		
		
		return added;
	}
	*/
	
}
