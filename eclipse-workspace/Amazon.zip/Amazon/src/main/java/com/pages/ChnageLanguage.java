package com.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ChnageLanguage {
	WebDriver driver;

	@FindBy(xpath = ("//span[text()='English'  and contains (@class, 'icp-color-base')]"))
	WebElement hover;
	@FindBy(xpath = ("/span[contains(text(),'हिंदी')] "))
	WebElement deatils ;
	
	
	public ChnageLanguage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);}
		
	public ChnageLanguage click () throws InterruptedException  {
		WebDriver driver = null;
		Actions actions = new Actions(driver);
		actions.moveToElement(hover).perform();
		
		Thread.sleep(2000);
        actions.click(deatils).perform();
		return new ChnageLanguage(driver);
		
	}

}
