package com.qa.Test;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.pages.AddCart;
import com.qa.TestBase.BaseClass;

import PageObject.HomePage;

public class AddCartTest2 extends BaseClass
{
@Test
public void added() throws InterruptedException {
		test = extent.createTest("Create site Test");
		AddCart abc= new AddCart();
		System.out.println();
	    abc.test();
		/*String act= abc.getSuccessMessage();
	
		String exp = "Successfully created the account";
		if (act.equals(exp)) {
			Assert.assertTrue(true);

		} else {
			Assert.assertTrue(false);

	    }*/
}}
	

