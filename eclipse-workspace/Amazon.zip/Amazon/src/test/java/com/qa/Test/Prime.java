package com.qa.Test;

import org.testng.Assert;

import com.pages.AddCart;
import com.qa.TestBase.BaseClass;

public class Prime extends BaseClass {
	public void join() throws InterruptedException {
		test = extent.createTest("Create site Test");
		AddCart abc= new AddCart();
		System.out.println();
	    abc.Test4();
		
	
		String exp = "Successfully created the account";
		if (act.equals(exp)) {
			Assert.assertTrue(true);

		} else {
			Assert.assertTrue(false);
	}

}}
